# Albertus Robinson Construction — Trust Coupon Referral Page

**Status: built for review. Not published. Not approved for printing.**

## What's in this package

| File | Purpose |
|---|---|
| `referral/index.html` | The referral landing page (one self-contained file, no frameworks) |
| `referral/arc-logo.png` | Your transparent-background ARC logo (330 × 264 px). The page also has this same logo built in, so it shows even if this file isn't uploaded |
| `qr/arc-referral-qr.svg` | QR code only, vector — preferred for the printer |
| `qr/arc-referral-qr.png` | QR code only, 2968 × 2968 px, 600 dpi |
| `qr/arc-referral-qr-labeled.svg` / `.png` | QR + "Scan to request your roof inspection." + "builtbyarc.pro/referral" |
| `tools/make_qr.py` | Regenerates the QR files if the destination URL has to change |

QR destination: `https://www.builtbyarc.pro/referral?utm_source=customer_referral&utm_medium=print&utm_campaign=trust_coupon`
Black on white, 4-module quiet zone, error correction level M, no logo. Decoded successfully by software at full size and when shrunk; that is **not** a substitute for scanning a printed proof.

---

## 1. Before launch — items I need from you

1. **Form inbox (confirm).** The page is wired to **Web3Forms**, the same service your main site's contact form uses, with the access key from that site. Confirm that key is still active and that its registered email is where referral requests should go. Log in to web3forms.com to check which inbox the key delivers to.
   - A Web3Forms access key is designed to sit in public HTML; it only lets someone send a message *to* your inbox. It is not a secret API key.
   - To use a different key, edit one line near the bottom of `referral/index.html`: `accessKey: '…'`. If that value is blank, the form refuses to submit and tells the visitor it isn't connected — it never fakes success.
2. **Logo.** Your transparent-background logo is built into the page itself, so it displays on any URL and when the file is opened directly. I trimmed only the empty transparent margin around the badge and scaled it evenly — no cropping of the logo, recoloring, or background changes. `arc-logo.png` is included as a separate copy for reuse.
3. **Roofr details.** I have not verified any Roofr API, webhook, Zapier connection, or "Lead Source" custom field, so nothing sends directly to Roofr. If your Roofr account has a web-form/lead-intake integration, send me what you see in Roofr's settings and I'll check whether it can be wired in. Until then, use the manual process in section 4.
4. **Urgent requests.** The page says not to submit urgent requests through the form, but per your instructions it does not show a phone number. Consider whether you want to add your verified call/text number (e.g., "For urgent roof leaks, call …") so people know what to do instead.
5. **Not included on purpose:** reviews, certifications (including Atlas Pro+ Gold), warranties, "free" inspections, response times, referral rewards, privacy-policy link, Google Analytics / Meta Pixel. Tell me if you want any of these added. If you add analytics, keep names, phone numbers, and addresses out of events and URLs.

---

## 2. Upload to GitHub

1. Open your website repository on github.com.
2. **Add file → Upload files.** Drag in the whole `referral` folder (it contains `index.html` and `arc-logo.png`) so it lands at the repo root next to your homepage file.
3. Commit to the branch GitHub Pages publishes from (Settings → Pages shows which branch/folder).
4. Wait 1–3 minutes for Pages to rebuild (Actions tab shows a green check).

Do not upload the `qr`, `tools`, or this README to the site; they're for you.

## 3. Making `/referral` work — verify, don't assume

Using a folder (`referral/index.html`) is the most reliable way to get a clean `/referral` address on a static host. On GitHub Pages, a request for `/referral` normally redirects to `/referral/` and serves `index.html`. Confirm it on the live site:

1. Open `https://www.builtbyarc.pro/referral` on your phone — the page should load.
2. Open the full QR URL (above) — the page should load, and the address bar should still contain `utm_campaign=trust_coupon` after any redirect.
3. Open `https://www.builtbyarc.pro/referral/` (trailing slash) — should load.

**If step 1 or 2 fails** (404, or the `?utm_…` part disappears):
- Check whether the site is actually hosted somewhere other than GitHub Pages (Netlify, Cloudflare Pages, etc. — look at your domain's DNS or Settings → Pages). Tell me which, and I'll give the exact fix.
- Fallback: rename the file to `referral.html` at the repo root (the logo is built in, so nothing else changes), confirm `https://www.builtbyarc.pro/referral.html?utm_source=…` works, then regenerate the QR to that exact URL by editing `URL=` at the top of `tools/make_qr.py` and running `python3 tools/make_qr.py` inside the `qr` folder (needs `pip install segno pillow opencv-python`). Also change the printed text under the code to `builtbyarc.pro/referral.html`.

**Do not send the coupon to print until steps 1–2 pass and a printed proof scans** (checklist below).

---

## 4. Getting referral leads into Roofr (manual process)

Each submission arrives by email from Web3Forms, with the subject *"New Trust Coupon referral – roof inspection request (referred by NAME)"*. For each one:

1. In Roofr, create a new lead/job for the homeowner: name, phone, email (if given), and the property address/city/ZIP from the email.
2. Set **Lead Source** to `Customer Referral – Trust Coupon`. If that option doesn't exist in your Roofr lead-source list, add it once in Roofr's settings so it can be reported on consistently.
3. Record the **referrer** separately: use a dedicated referral/referrer field if your Roofr account has one; otherwise put `Referred by: NAME (Trust Coupon)` as the first line of the job notes.
4. Paste the homeowner's "What can we help with?", preferred contact method, and notes into the job notes.
5. Contact the homeowner by their preferred method. Remember: the submission is a request, not a booked appointment.
6. If "Who referred you?" was left blank, ask the homeowner during the first call and add it then.
7. Keep the email (move it to a "Referrals" folder) as the source record until the lead is in Roofr.

Every email also contains: `lead_source`, `campaign` (trust_coupon), `landing_page`, `utm_source`, `utm_medium`, `utm_campaign`.

---

## 5. Verification checklist

**Mobile layout**
- [ ] On an iPhone and an Android phone: no sideways scrolling; headline, intro, and the blue button fit on the first screen.
- [ ] Tapping "Request a Roof Inspection" jumps to the form.
- [ ] Phone field opens the number keypad; email field opens the email keyboard; ZIP opens numbers.
- [ ] Logo shows, crisp, not stretched.

**Real submission delivery**
- [ ] Submit one real test request (use your own phone and "TEST – please ignore" in the notes).
- [ ] Green thank-you message appears, and the email arrives in the expected inbox within a few minutes (check spam).
- [ ] Choose "Email" as the contact method with the email blank → the page asks for an email and does not send.

**Referral attribution**
- [ ] Test email shows `referred_by` with the name you typed, and `lead_source: Customer Referral – Trust Coupon`.
- [ ] Test arriving via the QR code shows `utm_source: customer_referral`, `utm_medium: print`, `utm_campaign: trust_coupon`, and `landing_page` = the live referral URL.
- [ ] Enter the test lead into Roofr using section 4, then delete it.

**Error handling**
- [ ] Turn on airplane mode, fill the form, submit → red "Your request was not sent" message, entries still filled in, no thank-you message.
- [ ] Turn airplane mode off, tap submit again → it sends once (only one email arrives).
- [ ] Rapidly tapping the submit button sends only one request.

**Printed QR code**
- [ ] Print a proof of the actual coupon at final size. Keep the code at least **1.1 in (28 mm)** wide, plus the white margin around it — don't crop the white border.
- [ ] Scan both detachable coupons with the iPhone Camera app and an Android camera, in normal indoor light, from about 6–10 inches.
- [ ] Each scan opens the live referral page (not a 404), and the URL contains the UTM values.
- [ ] Printed "builtbyarc.pro/referral" is readable and, typed by hand, reaches the page.

Only after all of the above pass is the coupon ready for printing.

---

## What I tested before handing this over (simulated, not live)

On a 390 px phone viewport with the submission service mocked: required-field errors appear and focus jumps to the first problem; email becomes required when "Email" is chosen; success shows only when the service returns `success: true`; a rejected or failed request shows an error and keeps all entries; triple-clicking submit sends one request; a blank access key shows "not connected" and sends nothing; the honeypot/too-fast check blocks bot-style submits; UTM defaults apply when the URL has none; all four QR files decode to the exact destination URL. **No real submission was sent to your inbox.**
