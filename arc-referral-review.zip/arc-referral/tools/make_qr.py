import segno, cv2
from PIL import Image, ImageDraw, ImageFont
URL="https://www.builtbyarc.pro/referral?utm_source=customer_referral&utm_medium=print&utm_campaign=trust_coupon"
q=segno.make(URL, error='m', micro=False)
print("version",q.version,"ecc",q.error)
# Code only: black on white, 4-module quiet zone
q.save("arc-referral-qr.svg", scale=10, border=4, dark="#000000", light="#FFFFFF", xmldecl=True, svgclass=None, lineclass=None)
# PNG: ~3000px wide -> prints sharp up to ~10in at 300dpi
mods=q.symbol_size(scale=1,border=4)[0]
scale=max(1,3000//mods)
q.save("arc-referral-qr.png", scale=scale, border=4, dark="#000000", light="#FFFFFF", dpi=600)
# Labeled coupon version
qr=Image.open("arc-referral-qr.png").convert("RGB")
W=qr.width; pad=int(W*0.05)
f1=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", int(W*0.052))
f2=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", int(W*0.06))
H=qr.height+int(W*0.2)
img=Image.new("RGB",(W,H),"white"); img.paste(qr,(0,0)); d=ImageDraw.Draw(img)
t1="Scan to request your roof inspection."; t2="builtbyarc.pro/referral"
y=qr.height-int(W*0.01)
for t,f,c in [(t1,f1,(20,33,61)),(t2,f2,(0,0,0))]:
    w=d.textlength(t,font=f); d.text(((W-w)/2,y),t,font=f,fill=c); y+=int(f.size*1.45)
img=img.crop((0,0,W,y+pad//2)); img.save("arc-referral-qr-labeled.png", dpi=(600,600))
# Labeled SVG (vector)
import io,re
buf=io.BytesIO(); q.save(buf,kind="svg",scale=10,border=4,dark="#000000",light="#FFFFFF",xmldecl=False)
s=buf.getvalue().decode()
w=int(re.search(r'width="(\d+)"',s).group(1)); h=int(re.search(r'height="(\d+)"',s).group(1))
inner=re.search(r'<svg[^>]*>(.*)</svg>',s,re.S).group(1)
H2=h+int(w*0.2)
svg=f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{H2}" viewBox="0 0 {w} {H2}">
<rect width="{w}" height="{H2}" fill="#FFFFFF"/>
<g>{inner}</g>
<text x="{w/2}" y="{h+w*0.04}" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-weight="700" font-size="{w*0.052:.1f}" fill="#14213D">Scan to request your roof inspection.</text>
<text x="{w/2}" y="{h+w*0.125}" text-anchor="middle" font-family="Arial, Helvetica, sans-serif" font-weight="700" font-size="{w*0.06:.1f}" fill="#000000">builtbyarc.pro/referral</text>
</svg>'''
open("arc-referral-qr-labeled.svg","w").write(svg)
# Verify decode
for p in ["arc-referral-qr.png","arc-referral-qr-labeled.png"]:
    im=cv2.imread(p); im=cv2.resize(im,(im.shape[1]//6,im.shape[0]//6),interpolation=cv2.INTER_AREA)
    val,_,_=cv2.QRCodeDetector().detectAndDecode(im); print(p, "OK" if val==URL else "FAIL", val)
print(Image.open("arc-referral-qr.png").size)
